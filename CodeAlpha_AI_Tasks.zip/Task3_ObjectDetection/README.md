# Task 3 — Object Detection
This task uses YOLOv8 to detect objects in images.