from ultralytics import YOLO

def detect_objects(image_path):
    model = YOLO('yolov8n.pt')  # small YOLOv8 model
    results = model.predict(image_path, save=True)
    return results

if __name__ == "__main__":
    print("Run detect_objects('your_image.jpg') to detect objects.")
