from deep_translator import GoogleTranslator
from gtts import gTTS

def translate_text(text, src='en', dest='fr'):
    translator = GoogleTranslator(source=src, target=dest)
    result = translator.translate(text)
    return result

if __name__ == "__main__":
    text = "Hello, how are you?"
    translated = translate_text(text, 'en', 'fr')
    print("Input:", text)
    print("Translated:", translated)
    tts = gTTS(translated, lang='fr')
    tts.save("output.mp3")
