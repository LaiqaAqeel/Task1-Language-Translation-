# Task 1 — Translation Tool
This task translates text between languages and generates speech output.