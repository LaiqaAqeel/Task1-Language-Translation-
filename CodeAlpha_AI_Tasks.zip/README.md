# CodeAlpha AI Internship Tasks

This repository contains 3 completed AI/ML tasks for the CodeAlpha Internship:

1. **Task 1 — Translation Tool**: Translate text between languages and generate speech.
2. **Task 2 — FAQ Chatbot**: Answer user queries using TF-IDF similarity.
3. **Task 3 — Object Detection**: Detect objects in images using YOLOv8.

Includes: Task folders, Final_Report.pdf, plots, requirements, and README.
