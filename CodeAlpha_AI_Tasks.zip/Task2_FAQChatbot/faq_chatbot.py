import random
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

faq = {
    "what is ai": "AI is the simulation of human intelligence by machines.",
    "what is machine learning": "ML is a subset of AI focused on training models from data.",
    "how are you": "I'm an AI bot, always here to help you!"
}

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(faq.keys())

def get_response(user_input):
    vec = vectorizer.transform([user_input])
    scores = cosine_similarity(vec, X)
    idx = scores.argmax()
    return list(faq.values())[idx]

if __name__ == "__main__":
    while True:
        q = input("You: ")
        if q.lower() in ["exit", "quit"]:
            break
        print("Bot:", get_response(q))
