# Task 2 — FAQ Chatbot
This chatbot answers user queries using TF-IDF and cosine similarity.